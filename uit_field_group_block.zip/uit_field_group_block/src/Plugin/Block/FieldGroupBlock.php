<?php

namespace Drupal\field_group_block\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Plugin\ContainerFactoryPluginInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Drupal\field_group_block\Service\FieldGroupRenderer;

/**
 * Provides a Field Group block.
 *
 * @Block(
 *   id = "field_group_block",
 *   admin_label = @Translation("Field Group Block"),
 *   category = @Translation("Content")
 * )
 */
class FieldGroupBlock extends BlockBase implements ContainerFactoryPluginInterface {

  protected FieldGroupRenderer $renderer;

  public function __construct(
    array $configuration,
    $plugin_id,
    $plugin_definition,
    FieldGroupRenderer $renderer
  ) {
    parent::__construct($configuration, $plugin_id, $plugin_definition);
    $this->renderer = $renderer;
  }

  public static function create(ContainerInterface $container, array $configuration, $plugin_id, $plugin_definition) {
    return new static(
      $configuration,
      $plugin_id,
      $plugin_definition,
      $container->get('field_group_block.renderer')
    );
  }

  public function defaultConfiguration() {
    return [
      'group_name' => '',
      'view_mode' => 'default',
    ];
  }

  public function blockForm($form, FormStateInterface $form_state) {
    $form['group_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Field group machine name'),
      '#required' => TRUE,
      '#default_value' => $this->configuration['group_name'],
      '#description' => $this->t('Example: group_sidebar'),
    ];

    $form['view_mode'] = [
      '#type' => 'textfield',
      '#title' => $this->t('View mode'),
      '#default_value' => $this->configuration['view_mode'],
    ];

    return $form;
  }

  public function blockSubmit($form, FormStateInterface $form_state) {
    $this->configuration['group_name'] = $form_state->getValue('group_name');
    $this->configuration['view_mode'] = $form_state->getValue('view_mode');
  }

  public function build() {
    return $this->renderer->renderGroup(
      $this->configuration['group_name'],
      $this->configuration['view_mode']
    );
  }

}
