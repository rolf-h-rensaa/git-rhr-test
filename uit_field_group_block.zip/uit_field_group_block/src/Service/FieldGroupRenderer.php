<?php

namespace Drupal\field_group_block\Service;

use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\Core\Entity\EntityDisplayRepositoryInterface;
use Drupal\Core\Routing\RouteMatchInterface;
use Drupal\Core\Render\RendererInterface;
use Drupal\node\NodeInterface;

class FieldGroupRenderer {

  protected EntityTypeManagerInterface $entityTypeManager;
  protected EntityDisplayRepositoryInterface $displayRepository;
  protected RouteMatchInterface $routeMatch;

  public function __construct(
    EntityTypeManagerInterface $entityTypeManager,
    EntityDisplayRepositoryInterface $displayRepository,
    RouteMatchInterface $routeMatch
  ) {
    $this->entityTypeManager = $entityTypeManager;
    $this->displayRepository = $displayRepository;
    $this->routeMatch = $routeMatch;
  }

  /**
   * Render a field group from the current node.
   */
  public function renderGroup(string $group_name, string $view_mode = 'default'): array {
    $node = $this->routeMatch->getParameter('node');

    if (!$node instanceof NodeInterface) {
      return [];
    }

    $bundle = $node->bundle();
    $display = $this->displayRepository
      ->getViewDisplay('node', $bundle, $view_mode);

    $groups = $display->getThirdPartySettings('field_group');

    if (empty($groups[$group_name])) {
      return [];
    }

    $group = $groups[$group_name];
    $children = $group['children'] ?? [];

    $build = [
      '#theme' => 'field_group_block',
      '#label' => $group['label'] ?? '',
      '#children' => [],
      '#cache' => [
        'contexts' => ['route'],
        'tags' => $node->getCacheTags(),
      ],
    ];

    $view_builder = $this->entityTypeManager->getViewBuilder('node');

    foreach ($children as $field_name) {
      if (!$node->hasField($field_name)) {
        continue;
      }

      $build['#children'][$field_name] =
        $view_builder->viewField($node->get($field_name), $view_mode);
    }

    return $build;
  }

}
